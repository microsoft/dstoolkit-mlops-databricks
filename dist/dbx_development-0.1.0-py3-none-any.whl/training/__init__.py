# Databricks notebook source


#%load_ext autoreload #
#%autoreload 2

# COMMAND ----------

dbutils.library.restartPython()
# COMMAND ----------

import os
from pyspark.sql import *
from pyspark.sql.functions import current_timestamp
from pyspark.sql.types import IntegerType
from pyspark.sql.types import FloatType, IntegerType, StringType
from pyspark.sql.functions import *
import mlflow.pyfunc
from databricks.feature_store import feature_table, FeatureLookup
from databricks import feature_store
import mlflow
from sklearn.model_selection import train_test_split
from mlflow.tracking import MlflowClient
import lightgbm as lgb
import mlflow.lightgbm
import yaml
import pathlib
import sys
from argparse import ArgumentParser
import mlflow
from azureml.core import Workspace
import os
from azureml.core.authentication import ServicePrincipalAuthentication
from databricks.sdk.core import Config
from dotenv import load_dotenv
from databricks.sdk import WorkspaceClient
from utils import * # Custom Package
import base64


# COMMAND ----------
# Remove
#import mlflow.azureml
#from pyspark.sql import SparkSession
#from helperFunctions.helperFunction import *
#from helperFunctions.helperFunction import test
#from azure.ai.ml.entities import ManagedOnlineEndpoint, ManagedOnlineDeployment
#from azure.ai.ml import MLClient
#from azure.ai.ml.entities import Model
#from azure.ai.ml.constants import AssetTypes
#import azureml.mlflow
#from azureml.mlflow import get_portal_url
#from mlflow.deployments import get_deploy_client
#from azure.identity import DefaultAzureCredential
#import azureml.core
#import datetime
#from mlflow.models.signature import infer_signature


def get_extenal_parameters():
    """
    Parameters Can Be Passed From An External CLI / Job
    They Are Stored In The Namespace Object

    :returns: The external_parameters Object

    """
    p = ArgumentParser()
    p.add_argument("--env", required=False, type=str)
    
    external_parameters = p.parse_known_args(sys.argv[1:])[0]
    
    return external_parameters


def is_running_in_databricks() -> bool:
    return "DATABRICKS_RUNTIME_VERSION" in os.environ


def set_up_spark():
    if is_running_in_databricks():
        return SparkSession.builder.getOrCreate()

    os.environ["USER"] = "anything"
    config = Config(profile="DEFAULT")
    
    from databricks.connect import DatabricksSession
    spark = DatabricksSession.builder.sdkConfig(config).getOrCreate()

    return spark

def load_dot_env_file():
    load_dotenv(".env")

def get_secret(w, scope: str, secret_name: str) -> str:
    """
    Gets a secret from the Databricks secrets store from the
    given scope as described by the secret name.
    This does not work using databricks-connect remotely.

    :param: scope: The secrets scope in which the secret is stored
    :type scope: str
    
    :param: secret_name: the name of the secret to retrieve
    :type secret_name: str
    
    :returns: The secret as a string
    :rtype: str
    
    """

    if os.environ.get(secret_name):
        return os.environ.get(secret_name)
    return w.dbutils.secrets.get(scope, secret_name)

def get_secrets_dict(w):
    """
    Gets the secrets from the Databricks secrets store
    
    :param w: The Workspace object
    :type w: Workspace
    
    :returns: The secrets as a dictionary
    :rtype: Dict[str, str]

    """
    secrets_dict = {
        "subscription_id": get_secret(w, "DBX_SP_Credentials", "SUBSCRIPTION_ID"),
        "service_principal_id": get_secret(w, "DBX_SP_Credentials", "DBX_SP_Client_ID"),
        "tenant_id": get_secret(w, "DBX_SP_Credentials", "DBX_SP_Tenant_ID"),
        "service_principal_password": get_secret(w, "DBX_SP_Credentials", "DBX_SP_Client_Secret"),
        "resource_group": get_secret(w, "AzureResourceSecrets", "RESOURCE_GROUP_NAME"),
        "workspace_name": get_secret(w, "AzureResourceSecrets", "AML_WS_NAME")
    }
    
    return secrets_dict


def get_azure_ml_obj(
    secrets_dict: Dict[str, str]
    ):
    
    """
    Gets the Azure ML workspace object for interacting with
    Azure ML resources

    :param tenant_id: The tenant ID
    :type: tenant_id: str

    :param service_principal_id: The service principal ID
    :type: service_principal_id: str

    :param service_principal_password: The service principal password
    :type: service_principal_password: str

    :param subscription_id: The subscription ID
    :type: subscription_id: str

    :param resource_group: The resource group
    :type: resource_group: str

    :param workspace_name: The workspace name
    :type: workspace_name: str

    :param workspace_region: The workspace region
    :type: workspace_region: str
        
    :returns: Initialised Workspace object
    :rtype: Workspace
    """
    
    svc_pr = ServicePrincipalAuthentication(
        tenant_id=secrets_dict['tenant_id'],
        service_principal_id=secrets_dict['service_principal_id'],
        service_principal_password=secrets_dict['service_principal_password']
    )

    return Workspace(
        subscription_id=secrets_dict['subscription_id'],
        resource_group=secrets_dict['resource_group'],
        workspace_name=secrets_dict['workspace_name'],
        auth=svc_pr      
    )


def set_mlflow(namespace, ws, experiment_name, track_in_azure_ml=False):
    if namespace.env is not None:
        params = yaml.safe_load(pathlib.Path(namespace.env).read_text())
        experiment_name = params['ML_PIPELINE_FILES']['TRAIN_REGISTER']['PARAMETERS']['EXPERIMENT_NAME']
        track_in_azure_ml = params['ML_PIPELINE_FILES']['TRAIN_REGISTER']['PARAMETERS']['TRACK_IN_AZURE_ML']

        if track_in_azure_ml:
            if track_in_azure_ml: 
                mlflow.set_tracking_uri(ws.get_mlflow_tracking_uri()) 
                mlflow.set_experiment(experiment_name) 
        else:
            mlflow.set_tracking_uri('databricks') 
            experiment_name = "/Shared/" + experiment_name
            mlflow.set_experiment(experiment_name) 
    else:
        if track_in_azure_ml: 
            mlflow.set_tracking_uri(ws.get_mlflow_tracking_uri()) 
            mlflow.set_experiment(experiment_name) 
        else:
            mlflow.set_tracking_uri('databricks') 
            experiment_name = "/Shared/" + experiment_name
            mlflow.set_experiment(experiment_name) 
    
    return experiment_name

def load_data(
        spark,
        dbx_dbfs_data_location,
        fs_data_version
        ):
    """
    Loads the data from the given path into a Spark DataFrame

    :param spark: The spark session
    :type spark: SparkSession

    :param data_path: The path to the data
    :type data_path: str

    :param fs_data_version: The version of the data in the feature store
    :type fs_data_version: int

    :returns: The data as a Spark DataFrame
    :rtype: DataFrame

    """
    #rounded_unix_timestamp_udf = udf(rounded_unix_timestamp, IntegerType())
    #raw_data = spark.read.table("feature_store_taxi_example.nyc_yellow_taxi_with_zips")
    
    taxi_data = spark.read.format("delta").option(
        "versionAsOf", 
        fs_data_version
        ).load(
        dbx_dbfs_data_location
        )
    
    taxi_data = rounded_taxi_data(spark, taxi_data)
    
    return taxi_data

def feature_lookup(
        feature_table_name: str,
        feature_lookups: List[FeatureLookup], 
        lookup_key: List[FeatureLookup]
        ):
    """
    Looks up the features from the feature store for the given data
    :param data: The data to lookup features for
    :type data: DataFrame
    :param feature_lookups: The list of FeatureLookups to perform
    :type feature_lookups: List[FeatureLookup]
    :returns: Feature LookUp Object
    :rtype: DataFrame
    """
    feature_lookup = [
        FeatureLookup( 
            table_name = feature_table_name,
            feature_names = feature_lookups,
            lookup_key = lookup_key,
            )
    ]
    return feature_lookup


def get_taining_data(spark, fs, data, feature_lookups, label, exclude_columns):
    """
    Creates a training set from the given data
    :param data: The data to create the training set from
    :type data: DataFrame
    :param feature_lookups: The list of FeatureLookups to perform
    :type feature_lookups: List[FeatureLookup]
    :param label: The label column
    :type label: str
    :param exclude_columns: The columns to exclude from the training set
    :type exclude_columns: List[str]
    :returns: The training set
    :rtype: DataFrame
    """


    training_set = fs.create_training_set(
        data,
        feature_lookups = feature_lookups,
        label = label,
        exclude_columns = exclude_columns
    )
    training_df = training_set.load_df()
    return training_df, training_set


def train_model_lgbm(
    spark,
    training_df,
    training_set,
    fs,
    model_params: Dict[str, str],
    model_name: str
    ):
    """
    Trains the model
    :param training_df: The training set
    :type training_df: DataFrame
    :param features_and_label: The features and label columns
    :type features_and_label: List[str]
    :param model_type: The type of model to train
    :type model_type: str
    :param model_params: The model parameters
    :type model_params: Dict[str, str]
    :returns: The trained model
    :rtype: PipelineModel
    """

    from sklearn import metrics
    import joblib
    features_and_label = training_df.columns

    # Collect data into a Pandas array for training
    data = training_df.toPandas()[features_and_label]
    train, test = train_test_split(data, random_state=123)
    X_train = train.drop(["fare_amount"], axis=1)
    X_test = test.drop(["fare_amount"], axis=1)
    y_train = train.fare_amount
    y_test = test.fare_amount


    mlflow.end_run()
    mlflow.autolog(exclusive=False)
    with mlflow.start_run():
        train_lgb_dataset = lgb.Dataset(
            X_train, 
            label=y_train.values
            )
        
        test_lgb_dataset = lgb.Dataset(
            X_test, 
            label=y_test.values
            )
        
        mlflow.log_param("num_leaves", "32")
        mlflow.log_param("objective", "regression")
        mlflow.log_param( "metric", "rmse")
        mlflow.log_param("learn_rate", "100")

        param = { 
                    "num_leaves": 32, 
                    "objective": "regression", 
                    "metric": "rmse"
                }
        num_rounds = 100

        # Train a lightGBM model
        model = lgb.train(
        param, 
        train_lgb_dataset, 
        num_rounds
        )

        # Below Should be In Predict

        #Save The Model  

        #self.create_model_folder()

        #model_file_path = self.get_model_file_path("taxi_example_fare_packaged")
        print(f"ModelFilePath: {model_file_path}")
        joblib.dump(
            model, 
            open(model_file_path,'wb')
        )
        mlflow.log_param("local_model_file_path", model_file_path)  

        expected_y  = y_test
        predicted_y = model.predict(X_test)

        r2 = metrics.r2_score(
            expected_y, 
            predicted_y
            )

        mlflow.log_metric(
            "r2",
            r2)
    
        
        fs.log_model(
            model,
            artifact_path="model_packaged",
            flavor=mlflow.lightgbm,
            training_set=training_set,
            registered_model_name=model_name
        )

        return model, model_file_path


def get_model_file_path(spark, model_name: str) -> str:
    """
    Saves the model to the given path
    :param model: The model to save
    :type model: PipelineModel
    :param model_file_path: The path to save the model to
    :type model_file_path: str
    """

    #model_file_path = os.path.join('/dbfs', self.model_folder, model_name)
    
    return model_file_path

def create_model_folder(spark):
    """
    Creates a folder for the model
    """
    #dbutils.fs.mkdirs(.model_folder)

def run():

    model_folder = "cached_models"
    w = WorkspaceClient() # Databricks Workspace Client
    external_parameters = get_extenal_parameters()
    spark = set_up_spark()
    load_dot_env_file() # Secrets For Local Development
    secrets_dict = get_secrets_dict(w)
    ws = get_azure_ml_obj(secrets_dict) # Azure ML Workspace Client
    set_mlflow(
        external_parameters,
        ws,
        experiment_name="ciaran_experiment_nyc_taxi",
        track_in_azure_ml=False
    )
    #data_path
    dbx_dbfs_data_location = "dbfs:/user/hive/warehouse/feature_store_taxi_example.db/nyc_yellow_taxi_with_zips"
    taxi_data = load_data(
        spark,
        dbx_dbfs_data_location=dbx_dbfs_data_location, 
        fs_data_version=0 # First Version Of Data 
        )
    

    fs = feature_store.FeatureStoreClient() # Feature Store Client
    
    pickup_feature_lookups = feature_lookup(
        feature_table_name="feature_store_taxi_example.trip_pickup_features", 
        feature_lookups=["mean_fare_window_1h_pickup_zip", "count_trips_window_1h_pickup_zip"],
        lookup_key=["pickup_zip", "rounded_pickup_datetime"]  
    )

    #import pdb; pdb.set_trace()

    dropoff_feature_lookups = feature_lookup(
        feature_table_name="feature_store_taxi_example.trip_dropoff_features", 
        feature_lookups=["count_trips_window_30m_dropoff_zip", "dropoff_is_weekend"],
        lookup_key=["dropoff_zip", "rounded_dropoff_datetime"]  
        )

    training_df, training_set = get_taining_data(
        fs,
        taxi_data,
        pickup_feature_lookups + dropoff_feature_lookups,
        label="fare_amount",
        exclude_columns=[
            "rounded_pickup_datetime",
            "rounded_dropoff_datetime"
        ]
    )
    #training_df, training_set = df_feature_lookup(taxi_data=taxi_data, ml_ex_obj=ml_ex_obj, fs=fs)

    model = train_model_lgbm(
        training_df, 
        training_set, # Feature Store Object Prior to df conversion (above)
        fs,
        model_params={
            "num_leaves": 32,
            "objective": "regression",
            "metric": "rmse"
        },
        model_name="taxi_example_fare_packaged"
    )

# COMMAND ----------

def dbx_execute_functions():
    #spark = DatabricksSession.builder.sdkConfig(config).getOrCreate()
    pickup_feature_lookups = feature_lookup(
        feature_table_name="feature_store_taxi_example.trip_pickup_features", 
        feature_lookups=["mean_fare_window_1h_pickup_zip", "count_trips_window_1h_pickup_zip"],
        lookup_key=["pickup_zip", "rounded_pickup_datetime"]  
    )

    print(pickup_feature_lookups)
# COMMAND ----------



if __name__ == "__main__":
    
    dbx_execute_functions()
# COMMAND ----------
























    #model_file_name1 = 'taxi_example_fare_packaged.pkl'
    #model_file_name2 = 'pyfunc_taxi_fare_packaged.pkl'
    #model_file_path1 = os.path.join('/dbfs', MachineLearningExperiment.model_folder, model_file_name1)
    #model_file_path2 = os.path.join('/dbfs', MachineLearningExperiment.model_folder, model_file_name2)
    #pyfunc_model = fareClassifier(model)
    #joblib.dump(pyfunc_model, open(model_file_path2,'wb'))      #Save The Model 

    #mlflow.end_run()
    #mlflow.autolog(exclusive=False)
    #with mlflow.start_run() as run:
    #    fs.log_model(
    #        pyfunc_model,
    #        "pyfunc_packaged_model",
    #        flavor=mlflow.pyfunc,
    #        training_set=training_set,
    #        registered_model_name="pyfunc_taxi_fare_packaged",
    #    )




